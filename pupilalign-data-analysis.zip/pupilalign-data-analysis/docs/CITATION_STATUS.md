# Citation status

The working project name is PupilAlign. Final author names, author order, institutional affiliations, paper title, publication identifier, repository URL and DOI have not been confirmed for this release. No fabricated citation or placeholder DOI is supplied. Add the verified citation and a valid CITATION.cff when these details are available.
