# Reproducibility coverage

Run `python scripts/validate_release.py` to check inventory, file hashes, numeric schemas, reply coverage, panel means and the cross-file reference/prediction matches. Run `python scripts/reproduce.py` to produce verified summaries in `outputs/`.

| Result | Public reproducibility |
|---|---|
| CV dimensional MAE and Spearman, pairwise accuracy | Recomputed from released prediction/reference rows |
| Figure 2 split-distribution means and percentiles | Recomputed from the 1,000 released split rows |
| 70/30 audit subgroup means and case-bootstrap interval | Recomputed from 100 released case-level gains |
| Individual split generation | Algorithm described, but cannot be regenerated exactly from independently shuffled reply slots |
| Confidence-weighted and globally corrected reference fitting | Not regenerated: confidence values and participant linkage are not included |
| CV model training or best-of-six generation | Not regenerated: trained weights and complete pinned training artifacts are not included |
| Raw child-linked audit uncertainty | Not regenerated: participant-linked raw audit records are not included |
| Frozen downstream baseline scores | Included as provided; not rescored by this repository |

The bootstrap uses NumPy's default_rng with seed 20261105 and 10,000 case resamples. Cases retain their input CSV order. Percentiles use NumPy's default linear quantiles. Spearman correlations use average ranks for ties. Scripts compare recomputed numeric values with the supplied tables to absolute tolerance 1e-9.

Figure 2 definitions are in FIGURE2_METHODS.md. Its 1,000 split-distribution percentiles describe random splitting conditional on the dataset, not participant-population confidence intervals. No new experiment or model training is needed to run the included scripts.
