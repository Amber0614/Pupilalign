# Data handling and ethics

This release contains numerical scores and task-level identifiers. It does not contain child names, child identifiers, contact details, school names, participant recruitment records, signed forms, full teaching prompts, images, or free-text participant responses. It should not be described as a release of all study data.

Question IDs encode study tasks and grade/semester context. Audit IDs identify assessment cases. The rating slots in `fig2_replies.csv` are shuffled independently within each reply: a given slot does not identify one person across replies or cases. Do not attempt to link slots or infer participant identities. Aggregation and removal of direct identifiers do not establish a formal privacy guarantee.

The author reports school-organized recruitment and distribution of informed-consent forms. Children participated after guardian informed consent and child assent. Signed returns and the precise assent documentation method were not inspected. This procedural confirmation does not itself establish that a consent form explicitly authorized every possible public-data use; the data owner is responsible for the release decision.

The inspected approval letter identifies Shanghai Jiao Tong University Committee on Ethics of Human-Related Scientific Research (English translation), approval 20260634I, review LL2026000813-1. No approval PDF or signatures are redistributed here. The printed sample size is 360; this number alone is not evidence of coverage for a separate audit cohort.

The reference cohort counts and the separately author-confirmed 18-child audit must not be added as unique participants because their overlap has not been established. No participant recruitment identity records are supplied.
