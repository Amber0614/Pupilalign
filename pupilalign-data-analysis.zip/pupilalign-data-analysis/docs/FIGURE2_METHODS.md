# School1 Figure 2 reanalysis

Status: a newly specified descriptive reanalysis, not a reconstruction of the published two-school Figure 2. Both requested CSV files are provided. There are 2,472 reply rows and 1,000 split iterations. No participant identifiers, names, prompts, or free-text responses are exported.

## Reply file

Each row identifies a question, tutor model, and grade. panel_q1/q2/q3 and panel_score are unweighted means of valid non-imputed ratings. Up to four individual three-dimension score vectors are included in reply-local shuffled slots; empty cells mean no additional rating. Slot numbers must not be used to link participants across replies or questions. reference_q1/q2/q3 and reference_score are the school1 confidence-weighted historical reference. judge_cv_prediction fields come from the historical school1_human five-fold run, using the same reference definition. This branch is included because it avoids the globally fitted rater correction, not because its results were better. The corrected historical run remains separately available. These are historical predictions with the provenance limitations in ANALYSIS_SCOPE.md, not a newly certified model.

## Split-half construction

The same retained questionnaire slots rated all three tutor responses within each of the 824 questions. Restrict to 804 questions whose panels have at least two valid raters, covering 2,412 replies. Exclude 20 singleton questions (60 replies). In each iteration, independently within each question, shuffle its raters and split into floor(n/2) and ceil(n/2) members. The same membership is used for all three models and all three rating dimensions within that question. A child may receive a different half assignment on another question: this is within-question panel repeatability, not a global split of participants. Use unweighted means over raters and the three dimensions. Compare the two halves directly. No imputed scores, rater-offset fitting, grade shrinkage, or Judge predictions enter this calculation. Seed: 20261105; iterations: 1,000.

## Ties and gap thresholds

Compare each of the three model pairs per eligible question. If either half has a tied model pair (absolute difference <= 1e-12), award 0.5 agreement, including when both halves tie. Otherwise award 1 for the same direction and 0 for opposite directions. Ties stay in the denominator; tie counts are exported. This tie convention differs from historical Judge evaluation, which excludes reference ties.

Thresholds 0, 0.25, 0.5, and 1 use absolute differences between FULL-PANEL unweighted mean scores, on the 0-5 scale, with inclusive >= comparison. They do not use held-out half-panel means or the confidence-weighted reference from the reply file. Threshold-zero includes full-panel ties. Because full-panel gap selection uses both halves, the threshold curve is conditional descriptive agreement and must not be interpreted as an independent noise ceiling or unbiased held-out accuracy. Its use of unweighted means also means it is not a direct ceiling for the weighted-reference Judge metric.

## Correlations and uncertainty

across_question_spearman compares the two halves after averaging the three model scores within each question (804 question-level values). across_reply_spearman separately compares all 2,412 eligible reply scores. Spearman uses average ranks for ties. These are different estimands and are explicitly separated. The summary reports the mean and 2.5th/97.5th percentiles over random splits. These describe split randomness conditional on this dataset, not population confidence intervals. The iterations are not independent new participant samples, and no Spearman-Brown correction is applied.

Use scripts/reproduce.py to verify summaries from the released tables. Exact split regeneration requires the matched-rater source panels, which are not included in this release. The single-school restriction was chosen after viewing previous analyses; do not label this preregistered or an untouched validation study. Downstream tutor selection, original manuscript claims, and the independent 18-child audit have not been recomputed by this export.
