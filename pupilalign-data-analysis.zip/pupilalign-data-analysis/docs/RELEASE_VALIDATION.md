# Release validation

The prepared release contains 17 numerical tables and a 177-column table-specific dictionary. Every input table has a row/column inventory and SHA-256 checksum. Direct child identifier fields, free-text rating fields, Chinese source text, local home/storage paths and common credential patterns were checked and were not found in the release payload. This is a targeted content check, not a formal anonymity guarantee.

Numeric data were preserved from the reviewed author handoff. Only the internal source-path column in audit_040_length_check.csv was omitted. No model output, rating, count or statistic was changed for public packaging.

The validator checks row coverage, all reply/reference/prediction links, means reconstructed from individual reply-local score vectors, grade totals and split-row ranges. The reproduction script independently checks dimensional CV MAE/Spearman, pairwise metrics, split summary statistics and audit subgroup means/bootstrap. Environment: Python 3.10.12, NumPy 2.2.5, SciPy 1.15.2.

The release owner confirmed MIT for code and CC BY 4.0 for data and documentation. Public repository metadata are not inferred from passing these checks and remain unset until publication.
