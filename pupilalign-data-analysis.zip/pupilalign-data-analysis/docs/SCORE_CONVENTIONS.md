# Score conventions

q1 is ease of understanding, q2 is interest and engagement, and q3 is desire to continue exploring. Combined scores use the arithmetic mean of the three dimensions. Reference-panel source scores were validated in the numeric range 0-5. The separate tutor audit uses the 1-5 scale; released audit gains are differences, not absolute ratings. Judge predictions are supplied as stored, without additional clipping by the public scripts.

All agreement values, accuracy values, variance shares and length_pass values are proportions rather than percentages. Correlations range from -1 to 1. Score gains and MAE use the original score units. The final row of locked_test_baselines.csv is a paired difference, not a fifth condition score.

Empty panel-slot cells indicate that the reply has fewer than four ratings. No missing score is encoded as zero. Slot numbers are local to a reply. The all row in participant counts is a total and must not be added to the grade rows again. Individual exclusion-rule counts overlap, whereas exclusion-combination rows partition the exclusions.
