# Publishing the prepared repository

The local repository uses the main branch and contains the files needed for the data-and-analysis release. It has not been uploaded. Choose the owner account or organization and the repository name before publishing; no remote URL is guessed.

Validate locally:

```bash
python scripts/validate_release.py
python scripts/reproduce.py
```

Create an empty GitHub repository named pupilalign-data-analysis under the chosen owner, then follow GitHub's "push an existing repository" instructions for its actual URL. Configure the intended Git author name and email locally before the first commit. Authenticate through an approved GitHub connection, SSH or the GitHub CLI; never put credentials in tracked files or send tokens in a chat.

The prepared ZIP contains the tracked payload but not the .git directory or generated outputs. It can also be extracted and uploaded using GitHub's web interface. Keep data/, docs/, config/ and scripts/ as separate directories. Do not upload the broader research workspace, source participant records or internal author-response package.

After publication, record the real repository URL in README.md and citation metadata. Add a release tag only when ready to identify a fixed version. A DOI should be added only if one is actually issued. Licensing is already specified in LICENSES.md.
