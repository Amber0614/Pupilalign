# Changelog

## Prepared release - 2026-11-05

- Added 17 numerical CSV tables with field-level documentation.
- Added source/scope, ethics and reproducibility explanations separately from data.
- Added standalone CPU scripts for release validation and summary reproduction.
- Kept model weights, private participant linkage, prompts and internal author correspondence outside this repository.
- Added MIT code licensing and CC BY 4.0 licensing for data and documentation following owner confirmation.
- Public repository URL and citation metadata remain pending.
