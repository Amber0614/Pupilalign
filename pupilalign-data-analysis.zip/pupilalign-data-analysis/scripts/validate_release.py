#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Validate the release inventory, schemas, hashes and cross-file numerical links."""
import csv
import hashlib
import math
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def read(path):
    with path.open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))

def require(condition, message):
    if not condition:
        raise ValueError(message)

def close(x, y):
    return math.isclose(float(x), float(y), rel_tol=0, abs_tol=1e-10)

def main():
    for row in read(ROOT / 'CHECKSUMS.csv'):
        path = (ROOT / row['path']).resolve()
        require(ROOT in path.parents, 'Checksum path outside release')
        require(hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], f'Checksum mismatch: {row["path"]}')
    inventory = read(ROOT / 'docs' / 'DATA_INVENTORY.csv')
    dictionary = read(ROOT / 'docs' / 'DATA_DICTIONARY.csv')
    actual = {p.name for p in (ROOT / 'data').glob('*.csv')}
    require(actual == {r['file'] for r in inventory}, 'Inventory mismatch')
    for item in inventory:
        rows = read(ROOT / 'data' / item['file'])
        require(len(rows) == int(item['rows']), 'Row count mismatch')
        fields = list(rows[0])
        require(len(fields) == int(item['columns']), 'Column count mismatch')
        definitions = [d for d in dictionary if d['file'] == item['file']]
        require([d['column'] for d in definitions] == fields, 'Incomplete data dictionary')
        for definition in definitions:
            for row in rows:
                value = row[definition['column']]
                if value == '':
                    require(definition['missing_values'] == 'empty cell', 'Unexpected missing cell')
                elif definition['type'] in ('number', 'integer'):
                    require(math.isfinite(float(value)), 'Non-finite value')
                    if definition['type'] == 'integer':
                        require(float(value).is_integer(), 'Non-integer value')
    replies = read(ROOT / 'data' / 'fig2_replies.csv')
    refs = {(r['question_id'], r['model']): r for r in read(ROOT / 'data' / 'school1_reply_reference.csv')}
    predictions = {(r['question_id'], r['model']): r for r in read(ROOT / 'data' / 'cv_school1_human_predictions.csv')}
    keys = [(r['question_id'], r['model']) for r in replies]
    require(len(keys) == len(set(keys)) == 2472, 'Unexpected reply coverage')
    require(len({k[0] for k in keys}) == 824, 'Unexpected question count')
    require(set(keys) == set(refs) == set(predictions), 'Reference/prediction keys do not match')
    for row in replies:
        key = row['question_id'], row['model']
        for j in (1, 2, 3):
            vals = [float(row[f'panel_rating_{i}_q{j}']) for i in range(1, 5) if row[f'panel_rating_{i}_q{j}'] != '']
            require(len(vals) == int(row['panel_n']), 'Panel count mismatch')
            require(all(0 <= x <= 5 for x in vals), 'Panel score outside source range')
            require(close(sum(vals) / len(vals), row[f'panel_q{j}']), 'Panel mean mismatch')
            require(close(row[f'reference_q{j}'], refs[key][f'weighted_reference_q{j}']), 'Reference mismatch')
            require(close(row[f'judge_cv_prediction_q{j}'], predictions[key][f'prediction_q{j}']), 'Prediction mismatch')
    counts = read(ROOT / 'data' / 'school1_participant_counts.csv')
    total = next(r for r in counts if r['grade'] == 'all')
    for column in ('original_questionnaires', 'retained_questionnaires', 'questionnaires_contributing_valid_ratings'):
        require(sum(int(r[column]) for r in counts if r['grade'] != 'all') == int(total[column]), 'Grade totals mismatch')
    require([int(total[c]) for c in ('original_questionnaires', 'retained_questionnaires', 'questionnaires_contributing_valid_ratings')] == [360, 334, 332], 'Unexpected participant totals')
    splits = read(ROOT / 'data' / 'fig2_split_half.csv')
    require([int(r['iteration']) for r in splits] == list(range(1, 1001)), 'Split iteration mismatch')
    for row in splits:
        for column, value in row.items():
            if column.startswith('agreement_'):
                require(0 <= float(value) <= 1, 'Agreement outside range')
            if column.endswith('_spearman'):
                require(-1 <= float(value) <= 1, 'Correlation outside range')
    print('PASS: hashes, 17 table schemas, 2472 reply links, panel means, participant totals and 1000 split rows.')

if __name__ == '__main__':
    main()
