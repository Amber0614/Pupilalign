#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Recompute published descriptive summaries from local, de-identified CSVs."""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr
ROOT = Path(__file__).resolve().parents[1]

def read(path):
    with path.open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))

def write(path, rows):
    with path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def compare(actual, expected, keys, columns, tolerance=1e-9):
    a = {tuple(str(r[k]) for k in keys): r for r in actual}
    e = {tuple(str(r[k]) for k in keys): r for r in expected}
    if len(a) != len(actual) or len(e) != len(expected) or a.keys() != e.keys():
        raise ValueError('Duplicate or mismatched summary keys')
    for key in a:
        for column in columns:
            if not np.isclose(float(a[key][column]), float(e[key][column]), atol=tolerance, rtol=0):
                raise ValueError(f'Mismatch at {key}: {column}')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'data')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'outputs')
    args = parser.parse_args()
    data, out = args.data_dir.resolve(), args.output_dir.resolve()
    if out == data or data in out.parents:
        parser.error('Output directory must be separate from the input data directory.')
    out.mkdir(parents=True, exist_ok=True)
    results = []
    for run in ('human', 'corrected'):
        rows = read(data / f'cv_school1_{run}_predictions.csv')
        groups = defaultdict(list)
        for row in rows:
            groups[row['question_id']].append(row)
        if len(rows) != 2472 or len(groups) != 824 or any(len(v) != 3 for v in groups.values()):
            raise ValueError('Unexpected CV case coverage')
        prediction = np.array([[float(r[f'prediction_q{j}']) for j in (1, 2, 3)] for r in rows])
        truth = np.array([[float(r[f'reference_q{j}']) for j in (1, 2, 3)] for r in rows])
        rho = float(np.mean([spearmanr(prediction[:, j], truth[:, j]).statistic for j in range(3)]))
        pairs, clear = [], []
        for group in groups.values():
            for a in range(3):
                for b in range(a + 1, 3):
                    gap = float(group[a]['reference_score']) - float(group[b]['reference_score'])
                    if abs(gap) <= 1e-12:
                        continue
                    pgap = float(group[a]['prediction_score']) - float(group[b]['prediction_score'])
                    score = 0.5 if abs(pgap) <= 1e-12 else float(gap * pgap > 0)
                    pairs.append(score)
                    if abs(gap) >= 0.5:
                        clear.append(score)
        results.append(dict(training_labels=run, cases=len(groups), replies=len(rows),
                            mae_mean_three_dimensions=float(np.abs(prediction - truth).mean()),
                            srcc_mean_three_dimensions=rho,
                            pairwise_accuracy_recomputed=float(np.mean(pairs)),
                            pairwise_n_recomputed=len(pairs),
                            clear_pairwise_accuracy_recomputed=float(np.mean(clear)),
                            clear_pairwise_n_recomputed=len(clear)))
    compare(results, read(data / 'cv_summary.csv'), ['training_labels'], list(results[0])[1:])
    write(out / 'cv_summary.csv', results)

    splits = read(data / 'fig2_split_half.csv')
    if len(splits) != 1000:
        raise ValueError('Expected 1000 split iterations')
    split_summary = []
    for key in splits[0]:
        if key.startswith('agreement_') or key.endswith('_spearman'):
            values = np.array([float(r[key]) for r in splits])
            low, high = np.quantile(values, [0.025, 0.975])
            split_summary.append(dict(metric=key, mean=float(values.mean()),
                                      split_distribution_p2_5=float(low), split_distribution_p97_5=float(high)))
    compare(split_summary, read(data / 'fig2_split_half_summary.csv'), ['metric'], list(split_summary[0])[1:])
    write(out / 'fig2_split_half_summary.csv', split_summary)

    cases = read(data / 'audit_overlap_case_gains.csv')
    overlap = np.array([float(r['combined_gain']) for r in cases if r['in_judge_reference'] == '1'])
    nonoverlap = np.array([float(r['combined_gain']) for r in cases if r['in_judge_reference'] == '0'])
    if len(overlap) != 70 or len(nonoverlap) != 30:
        raise ValueError('Unexpected audit subgroup membership')
    rng = np.random.default_rng(20261105)
    draws = (rng.choice(overlap, (10000, 70)).mean(axis=1)
             - rng.choice(nonoverlap, (10000, 30)).mean(axis=1))
    low, high = np.quantile(draws, [0.025, 0.975])
    audit = [dict(overlap_cases=70, nonoverlap_cases=30, overlap_gain=float(overlap.mean()),
                  nonoverlap_gain=float(nonoverlap.mean()), gain_difference=float(overlap.mean() - nonoverlap.mean()),
                  case_bootstrap_percentile_low=float(low), case_bootstrap_percentile_high=float(high),
                  bootstrap_iterations=10000, seed=20261105)]
    compare(audit, read(data / 'audit_overlap_summary.csv'), [], list(audit[0]))
    write(out / 'audit_overlap_summary.csv', audit)
    report = dict(status='passed', cv_rows=2472, cv_questions=824, split_iterations=1000, audit_cases=100,
                  verified=['CV MAE, dimensional Spearman and pairwise metrics', 'split-table summaries',
                            'audit subgroup means and case bootstrap'],
                  limitations=['No model retraining', 'No exact split regeneration from raw panels',
                               'No participant-level bootstrap'])
    (out / 'reproduction_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
