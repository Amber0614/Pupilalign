# License scope

The release owner confirmed the following licensing choice:

| Material | License |
|---|---|
| scripts/, requirements.txt and .gitignore | MIT; see LICENSE |
| data/, config/, docs/, README.md and CHANGELOG.md | CC BY 4.0; see LICENSE-DATA.md |

The script source and its inline documentation are covered by MIT. The research documentation in docs/ is covered by CC BY 4.0. The root MIT file does not override the separate data/documentation license. Third-party dependencies retain their own licenses; they are installed from requirements.txt and are not redistributed as part of this repository.

"PupilAlign contributors" is the project-level attribution label. It is not a substitute for the final paper author list. Citation metadata can be added when verified. Public repository URL and release DOI remain unset until publication.
