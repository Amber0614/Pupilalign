# Data and documentation license

Copyright 2026 PupilAlign contributors.

Except where otherwise indicated, the numerical tables in data/, the configuration records in config/, the documentation in docs/, and the repository README and CHANGELOG are licensed under the Creative Commons Attribution 4.0 International license (CC BY 4.0).

The applicable legal terms are the [CC BY 4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en). The [license deed](https://creativecommons.org/licenses/by/4.0/) provides a summary and does not replace those terms.

When reusing this material, attribute "PupilAlign contributors, PupilAlign: data and analysis companion", retain the license notice, link to the source repository and the license, and indicate modifications. Once published, use the actual repository URL and commit or release version. No repository URL or DOI is fabricated in this prepared copy.

This license covers only the material distributed here. It grants no rights to excluded participant records, third-party model weights or source teaching materials. Code licensing is specified separately in LICENSES.md.
