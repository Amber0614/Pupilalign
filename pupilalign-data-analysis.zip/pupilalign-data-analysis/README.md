# PupilAlign: data and analysis companion

English numerical data and analysis scripts accompanying the PupilAlign author-information materials. This repository contains reference scores, saved cross-validated predictions, descriptive split-half statistics, and audit summaries. It does not contain model weights or the full training pipeline.

## Quick start

Tested with Python 3.10.12, NumPy 2.2.5 and SciPy 1.15.2. No API key or GPU is required.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/validate_release.py
python scripts/reproduce.py
```

Outputs go to `outputs/`, which is ignored by Git. The scripts read only the released CSVs. They verify the CV summary, summarize the 1,000 supplied splits, and reproduce the audit subgroup calculation. Exact split regeneration needs matched-rater source panels that are not included; see [reproducibility coverage](docs/REPRODUCIBILITY.md).

## Main files

| File | Contents |
|---|---|
| `data/fig2_replies.csv` | 2,472 replies from 824 questions: model, grade, panel scores, reference and Judge prediction |
| `data/fig2_split_half.csv` | 1,000 splits: agreement by gap threshold, question-level and reply-level correlations |
| `data/school1_participant_counts.csv` | 360 original questionnaires, 334 retained and 332 contributing valid ratings |
| `data/cv_school1_human_predictions.csv` | Predictions from the five-fold run trained on confidence-weighted school1 scores |
| `data/cv_school1_corrected_predictions.csv` | Predictions from the five-fold run trained on corrected school1 scores |
| `data/audit_overlap_case_gains.csv` | 100 case-level audit gains with reference-set overlap indicators |

Additional tables describe sensitivity analyses, grade-specific diagnostics, exclusion counts, baselines and case-pool sizes. [The inventory](docs/DATA_INVENTORY.csv) lists every table; [the data dictionary](docs/DATA_DICTIONARY.csv) defines every column.

## Interpretation

Read [analysis scope](docs/ANALYSIS_SCOPE.md) with the tables. The single-school reference analysis and existing downstream evaluations have different scopes; reusing their outputs does not mean the downstream pipeline was revalidated with a revised Judge. No new experiment or model training was conducted for this release.

For Figure 2, split halves compare two panels directly. Gap thresholds use full-panel unweighted means; ties in either half receive half credit. There are 804 eligible questions and 20 excluded singleton questions. These are descriptive statistics, not an independently established noise ceiling. See [Figure 2 methods](docs/FIGURE2_METHODS.md).

The audit involves 18 author-confirmed children, three per grade; 300 rating records are not 300 participants. Its 100-case overlap analysis is exploratory and the case bootstrap does not model repeated-child dependence. See [audit methods](docs/AUDIT_SUBGROUPS.md).

## Data handling

No child names, participant identifiers, recruitment lists, consent forms, source prompts or free-text child responses are included. Reply-local score slots are shuffled independently per reply and must not be used as participant identifiers. Question and audit IDs identify study tasks, not children. See [data handling and ethics](docs/DATA_HANDLING.md).

## Citation and licensing

Author metadata, the final paper citation, repository URL and release DOI have not been supplied. See [citation status](docs/CITATION_STATUS.md). Code is licensed under [MIT](LICENSE); data and research documentation are licensed under [CC BY 4.0](LICENSE-DATA.md). See [license scope](LICENSES.md). This local preparation is not a claim of an already published GitHub repository.
